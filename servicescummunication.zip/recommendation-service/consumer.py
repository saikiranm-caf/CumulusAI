import asyncio
import json
import aio_pika
from aio_pika import Message
from config import settings
from schemas import RecommendationRequest
from tasks import process_recommendation_task

async def handle_message(msg: aio_pika.IncomingMessage):
    async with msg.process():
        payload = json.loads(msg.body.decode())
        req = RecommendationRequest(**payload)
        await process_recommendation_task(req)

async def handle(payload):
    req = RecommendationRequest(**payload)
    result = await process_recommendation_task(req)
    return result

async def on_request(message: aio_pika.IncomingMessage):
    async with message.process():          # ack it
        payload = json.loads(message.body)
        # … do your work, e.g.:
        result = await handle(payload)     # or plain handle() if sync

        # build a new AMQP message, echoing that same correlation_id
        reply = Message(
            body=json.dumps(result).encode(),
            correlation_id=message.correlation_id
        )

        # publish back to whatever queue the client asked us to reply to
        await message.channel.default_exchange.publish(
            reply,
            routing_key=message.reply_to
        )

async def main():
    connection = await aio_pika.connect_robust(str(settings.RABBITMQ_URL))
    channel = await connection.channel()
    queue = await channel.declare_queue(settings.QUEUE_NAME, durable=True)
    await queue.consume(handle_message)
    print(f"🟢 Consumer listening on `{settings.QUEUE_NAME}`")
    await asyncio.Future()  # keep running

if __name__ == "__main__":
    asyncio.run(main())

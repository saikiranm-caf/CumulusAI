import uvicorn
from fastapi import FastAPI, Query
from schemas import RecommendationRequest
from publisher import publish_recommendation_request
from config import settings

app = FastAPI(title=settings.APP_NAME)

@app.get("/recommendation")
async def recommendation_endpoint(
    user_id: str = Query(...),
    lat: float    = Query(...),
    lon: float    = Query(...)
):
    task = RecommendationRequest(user_id=user_id, lat=lat, lon=lon)
    await publish_recommendation_request(task)
    return {"message": f"Enqueued recommendation for {user_id}"}

if __name__ == "__main__":
    uvicorn.run(
        "main:app", host="0.0.0.0", port=settings.PORT, reload=True
    )

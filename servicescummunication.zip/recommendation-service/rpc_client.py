# recommendation-service/rpc_client.py
import os, json, uuid, asyncio
import aio_pika
from config import settings

async def rpc_call(queue_name: str, payload: dict, timeout: float = 60.0): # Changed timeout to 30 seconds
    conn = await aio_pika.connect_robust(str(settings.RABBITMQ_URL))
    channel = await conn.channel()
    callback_q = await channel.declare_queue(exclusive=True)
    corr_id   = str(uuid.uuid4())
    future    = asyncio.get_running_loop().create_future()

    async def on_response(msg: aio_pika.IncomingMessage):
        if msg.correlation_id == corr_id:
            future.set_result(json.loads(msg.body))
    await callback_q.consume(on_response)

    await channel.default_exchange.publish(
        aio_pika.Message(
            body=json.dumps(payload).encode(),
            correlation_id=corr_id,
            reply_to=callback_q.name,
        ),
        routing_key=queue_name,
    )
    return await asyncio.wait_for(future, timeout)